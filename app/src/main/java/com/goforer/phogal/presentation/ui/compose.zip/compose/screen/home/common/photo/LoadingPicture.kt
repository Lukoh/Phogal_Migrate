package com.goforer.phogal.presentation.ui.compose.screen.home.common.photo

import android.content.res.Configuration
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.StartOffsetType
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.goforer.base.designsystem.component.LoadingIndicator
import com.goforer.phogal.presentation.ui.theme.ColorSystemGray7
import com.goforer.phogal.presentation.ui.theme.DarkGreen10
import com.goforer.phogal.presentation.ui.theme.PhogalTheme
import com.google.accompanist.placeholder.PlaceholderHighlight
import com.google.accompanist.placeholder.material.placeholder
import com.google.accompanist.placeholder.material.shimmer

@Composable
fun LoadingPicture(
    modifier: Modifier = Modifier,
    enableLoadIndicator: Boolean = false
) {
    BoxWithConstraints(
        modifier = modifier.clip(RoundedCornerShape(4.dp))
    ) {
        // 1. Scope 활용 예시: 화면 높이가 너무 작을 때의 대응 (필요 시)
        val isSmallScreen = maxHeight < 100.dp

        Column(modifier = Modifier.fillMaxSize()) {
            Card(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ColorSystemGray7)
                    .placeholder(
                        visible = true,
                        color = MaterialTheme.colorScheme.surface,
                        placeholderFadeTransitionSpec = { tween(durationMillis = 400) },
                        contentFadeTransitionSpec = { tween(durationMillis = 400) },
                        highlight = PlaceholderHighlight.shimmer(
                            animationSpec = infiniteRepeatable(
                                animation = keyframes {
                                    durationMillis = 800
                                    0f at 0
                                    0f at 200
                                    1f at 800 with FastOutSlowInEasing
                                },
                                repeatMode = RepeatMode.Reverse,
                                initialStartOffset = StartOffset(
                                    offsetType = StartOffsetType.FastForward,
                                    offsetMillis = 200
                                )
                            )
                        )
                    ),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
            ) {}
        }

        if (enableLoadIndicator) {
            LoadingIndicator(
                // 2. 외부 modifier를 또 쓰지 않고, 내부 배치를 위한 Modifier 사용
                modifier = Modifier
                    .align(Alignment.Center) // 중앙 정렬 (BoxScope 활용)
                    .padding(vertical = if (isSmallScreen) 10.dp else 22.dp),
                color = DarkGreen10
            )
        }
    }
}

@Preview(name = "Light Mode")
@Preview(
    uiMode = Configuration.UI_MODE_NIGHT_YES,
    showBackground = true,
    name = "Dark Mode",
    showSystemUi = true
)
@Composable
fun LoadingPicturePreview(modifier: Modifier = Modifier) {
    PhogalTheme {
        BoxWithConstraints(
            modifier = modifier.clip(RoundedCornerShape(4.dp))
        ) {
            // 1. maxWidth를 활용해 높이를 가변적으로 설정 (예: 너비의 0.7배, 최대 256.dp)
            // 이 코드가 추가됨으로써 'Scope is not used' 경고가 해결됩니다.
            val dynamicHeight = minOf(maxWidth * 0.7f, 256.dp)

            Column {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(dynamicHeight) // 계산된 가변 높이 적용
                        .background(ColorSystemGray7)
                        .placeholder(
                            visible = true,
                            color = MaterialTheme.colorScheme.surface,
                            placeholderFadeTransitionSpec = { tween(durationMillis = 400) },
                            contentFadeTransitionSpec = { tween(durationMillis = 400) },
                            highlight = PlaceholderHighlight.shimmer(
                                animationSpec = infiniteRepeatable(
                                    animation = keyframes {
                                        durationMillis = 800
                                        0f at 0
                                        0f at 200
                                        1f at 800 with FastOutSlowInEasing
                                    },
                                    repeatMode = RepeatMode.Reverse,
                                    initialStartOffset = StartOffset(
                                        offsetType = StartOffsetType.FastForward,
                                        offsetMillis = 200
                                    )
                                )
                            )
                        ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
                ) {}
            }

            // 2. LoadingIndicator는 BoxScope를 활용해 중앙 정렬
            LoadingIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = DarkGreen10
            )
        }
    }
}