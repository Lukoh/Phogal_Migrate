package com.goforer.phogal.presentation.ui.compose.screen.home.gallery

import android.content.res.Configuration
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.StartOffsetType
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.goforer.base.designsystem.component.LoadingIndicator
import com.goforer.phogal.presentation.ui.theme.ColorSystemGray7
import com.goforer.phogal.presentation.ui.theme.DarkGreen10
import com.goforer.phogal.presentation.ui.theme.PhogalTheme
import com.google.accompanist.placeholder.PlaceholderHighlight
import com.google.accompanist.placeholder.material.placeholder
import com.google.accompanist.placeholder.material.shimmer

@Composable
fun LoadingPhotos(
    modifier: Modifier = Modifier,
    count: Int,
    enableLoadIndicator: Boolean = false
) {
    BoxWithConstraints(modifier = modifier.clip(RoundedCornerShape(4.dp))) {
        // 2. 화면 너비에 따른 동적 수치 계산 (Scope 사용으로 에러 해결)
        val isWideScreen = maxWidth > 600.dp
        val cardHeight = if (isWideScreen) 320.dp else 256.dp
        val horizontalPadding = if (isWideScreen) 16.dp else 0.dp

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = horizontalPadding)
        ) {
            repeat(count) { // for 대신 repeat 사용 권장
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(cardHeight) // 동적 높이 적용
                        .placeholder(
                            visible = true,
                            color = MaterialTheme.colorScheme.surface,
                            highlight = PlaceholderHighlight.shimmer(
                                animationSpec = infiniteRepeatable(
                                    animation = keyframes {
                                        durationMillis = 800
                                        0f at 0
                                        0f at 200
                                        1f at 800 with FastOutSlowInEasing
                                    },
                                    repeatMode = RepeatMode.Reverse,
                                    initialStartOffset = StartOffset(
                                        offsetMillis = 200,
                                        offsetType = StartOffsetType.FastForward
                                    )
                                )
                            ),
                            placeholderFadeTransitionSpec = { tween(400) },
                            contentFadeTransitionSpec = { tween(400) }
                        ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
                ) {
                    // Card 내부 컨텐츠 (필요시)
                }
                Spacer(modifier = Modifier.height(4.dp))
            }
        }

        if (enableLoadIndicator) {
            LoadingIndicator(
                modifier = Modifier // 파라미터로 받은 modifier 대신 새 Modifier 사용 (중첩 방지)
                    .align(Alignment.BottomCenter)
                    .padding(vertical = 22.dp),
                color = DarkGreen10
            )
        }
    }
}

@Preview(name = "Light Mode")
@Preview(
    uiMode = Configuration.UI_MODE_NIGHT_YES,
    showBackground = true,
    name = "Dark Mode",
    showSystemUi = true
)
@Composable
fun LoadingPhotosPreview(modifier: Modifier = Modifier) {
    PhogalTheme {
        BoxWithConstraints(
            modifier = modifier.clip(RoundedCornerShape(4.dp))
        ) {
            // 1. BoxWithConstraints의 속성(maxWidth)을 사용하여 에러 해결 및 동적 UI 구현
            val isWideScreen = maxWidth > 600.dp
            val cardHeight = if (isWideScreen) 320.dp else 256.dp

            Column {
                repeat(3) { // for 대신 repeat 사용 권장
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(cardHeight) // 화면 크기에 따른 가변 높이
                            .background(ColorSystemGray7)
                            .placeholder(
                                visible = true,
                                color = MaterialTheme.colorScheme.surface,
                                placeholderFadeTransitionSpec = { tween(durationMillis = 400) },
                                contentFadeTransitionSpec = { tween(durationMillis = 400) },
                                highlight = PlaceholderHighlight.shimmer(
                                    animationSpec = infiniteRepeatable(
                                        animation = keyframes {
                                            durationMillis = 800
                                            0f at 0
                                            0f at 200
                                            1f at 800 with FastOutSlowInEasing
                                        },
                                        repeatMode = RepeatMode.Reverse,
                                        // 2. 에러 수정: offsetMillis(Long)가 첫 번째 인자로 와야 함
                                        initialStartOffset = StartOffset(
                                            offsetMillis = 200,
                                            offsetType = StartOffsetType.FastForward
                                        )
                                    )
                                )
                            ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
                    ) {}
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }

            // 3. 로딩 인디케이터 정렬 최적화
            LoadingIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = DarkGreen10
            )
        }
    }
}